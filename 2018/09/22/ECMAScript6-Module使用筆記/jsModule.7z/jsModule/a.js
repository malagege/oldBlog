export var a = 1;
export default 2;