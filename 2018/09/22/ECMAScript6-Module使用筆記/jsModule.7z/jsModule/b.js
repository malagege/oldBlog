var a = 11;
var b = 22;
var c = 33;
var d = 44;

export {a,b}
export {c,d}
// export {a,c,d}
// SyntaxError: duplicate export name 'a'